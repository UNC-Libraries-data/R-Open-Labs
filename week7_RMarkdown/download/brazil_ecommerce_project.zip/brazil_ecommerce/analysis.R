# Purpose: Exploratory data analysis of Brazilian ecommerce data
# Author: Nuvan Rathnayaka
# Date: September 2018
# Source: https://www.kaggle.com/olistbr/brazilian-ecommerce

# Setup -----------------------------------------------------------
library(tidyverse)
library(GGally)

# Exercise 1 ------------------------------------------------------
olist_public <- read_csv("data/olist_public_dataset_v2.csv") 
dim(olist_public)
head(olist_public)
table(olist_public$customer_state)

ggplot(data=olist_public,aes(x=fct_infreq(customer_state)))+geom_bar(width=0.5)+theme_bw() +
  theme(axis.text.x = element_text(angle = 90))

ggplot(data=olist_public,aes(x=order_items_qty))+geom_histogram(bins=20)+theme_bw()

olist_public %>% 
  ggplot(aes(x=order_items_qty,y=order_products_value))+geom_point(alpha=0.05)+theme_bw()

expensive <- olist_public %>%
  filter(order_products_value > 2500)

table(expensive$product_category_name)
  
olist_public %>% 
  select("order_items_qty", "order_products_value", "review_score") %>% 
  ggpairs()

# Exercise 2 ------------------------------------------------------
product_category_name_translation <- read_csv("data/product_category_name_translation.csv") 
translated <- left_join(olist_public,
                        product_category_name_translation,
                        by="product_category_name")

expensive <- translated %>%
  filter(order_products_value > 2500)

table(expensive$product_category_name_english)

# Exercise 3 ------------------------------------------------------
summarized <- translated %>%
  group_by(customer_state, product_category_name_english) %>%
  summarise(total_item_qty = sum(order_items_qty, na.rm = TRUE))

# Exercise 4 ------------------------------------------------------
products <- spread(summarized, key = product_category_name_english, value = total_item_qty)


# Exercise 5 ------------------------------------------------------
products <- ungroup(products) #remove grouping 
products[is.na(products)] <- 0 #replace missing data with zeroes

# Exercise 6 ------------------------------------------------------
products %>% 
  select("small_appliances", "consoles_games", "air_conditioning", "construction_tools_safety") %>% 
  ggpairs()

# Exercise 7 ------------------------------------------------------
summarized2 <- translated %>%
  group_by(customer_state, product_category_name_english) %>%
  summarise(total_order_value = sum(order_products_value, na.rm = TRUE)) %>%
products2 <-  spread(summarized2, key = product_category_name_english, value = total_order_value)
products2 <- ungroup(products2) #remove grouping 
products2[is.na(products2)] <- 0 #replace missing data with zeroes
products2 %>% 
  select("small_appliances", "consoles_games", "air_conditioning", "construction_tools_safety") %>% 
  ggpairs()

# Exercise 8 ------------------------------------------------------
products_state <- products %>%
  gather(key = "product_category_name_english", value = "total_item_qty", -customer_state) %>%
  spread(key = customer_state, value = total_item_qty)

# Exercise 9 ------------------------------------------------------
products_state %>% 
  select("AC", "AL", "AM", "AP", "BA") %>% 
  ggpairs()

